#include <reg51.h>

#define fimTempo 100 //timer = 0.2ms -> fimTempo=100*0.2ms=20ms
#define zero 3 //3*0.2ms=0.6ms -> 0�
#define centoOitenta 12 //12*0.2=2.4ms -> 180�
#define atraso 13 //100*20ms = 2s

sbit sensorLuz = P3^2; //pino de controlo do sensor
sbit servo = P1^0; //pino de controlo do servo motor
sbit led = P1^1; //pino do led

unsigned char conta = 0; //contador que incrementa a cada 200us
unsigned char conta2 = 0; //tempo de espera entre mudan�a de angulos
unsigned char referencia = zero; //o servo motor come�a nos 0�

unsigned char atualiza = 1;

unsigned char luzdetetada = 0; //o servo motor come�a nos 0�

//declara��o de fun��es
void Init(void);

void Init(void)
{
	//Configuracao Registo IE
	EA = 1; //ativa interrupcoes globais
	ET0 = 1; // ativa interrupcao timer 0
	
	EX0 = 1; // ativa interrupcao externa 0
	
	//Configuracao Registo TMOD
	TMOD &= 0xF0; //limpa os 4 bits do timer 0 (8 bits � auto reload)
	TMOD |= 0x02; //modo 2 do timer 0
	
	//Configuracao Timer 0
	TH0 = 0x37; //Timer 0 - 200us
	TL0 = 0x37;
	
	//Configuracao Registo TCON
	TR0 = 1; //comeca o timer 0
	IT0 = 1; //interrupcao externa activa a falling edge
	
	led = 1; //led desligado
}

//interrupcao externa
void External0_ISR(void) interrupt 0
{
	luzdetetada = 1; //assinala que o sensor detetou luz
	led = 0; //liga led
}

//interrupcao tempo
void Timer0_ISR(void) interrupt 1
{
	conta++; //incrementa a cada contagem de 200us
}

void main(void)
{
	//inicializa��es
	Init();
	
	while(1) //loop infinito
	{ 	
			//atingiu o valor de referencia (0.6ms, 1.4ms ou 2.4ms)			
		if(conta == referencia){
			servo = 0; //coloca a sa�da a 0 at� atingir os 20ms
		}
			
			//atingiu os 20ms
		if(conta == fimTempo){
				conta = 0; //reinicia a contagem
				servo = 1; //impulso positivo at� atingir o valor de referencia
				conta2++; //incrementa 20ms na contagem do tempo de espera entre mudan�a de angulos
		}
			
			//se atingiu o tempo definido de espera para mudar de �ngulo
			//ATRASO_IF
		if(conta2 == atraso)
		{
			if(luzdetetada == 1){
				if(sensorLuz == 1){ //verfica se a interrup��o externa foi desativada
					luzdetetada = 0; //anula a interrup��o
					led = 1; //desliga led
				}
			}
			else {
				if(referencia == centoOitenta)
					atualiza = -1;
				if(referencia == zero)
					atualiza = 1;
					
				referencia = referencia + atualiza;
			}
		conta2 = 0; //reinicia a contagem do tempo
		}
	}
}