/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Universidade/SD/ProjectoSD/comp.v";
static int ng1[] = {1, 0};
static int ng2[] = {0, 0};



static void Always_10_0(char *t0)
{
    char t4[8];
    char t15[8];
    char t44[8];
    char t73[8];
    char t102[8];
    char t138[8];
    char t156[8];
    char t171[8];
    char t206[8];
    char t221[8];
    char t256[8];
    char t271[8];
    char t306[8];
    char t321[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;
    char *t43;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    char *t72;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    char *t100;
    char *t101;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    char *t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    char *t135;
    char *t136;
    char *t137;
    char *t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    char *t152;
    char *t153;
    char *t154;
    char *t155;
    char *t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    char *t170;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    char *t175;
    char *t176;
    char *t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    char *t185;
    char *t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    int t195;
    int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    char *t203;
    char *t204;
    char *t205;
    char *t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    unsigned int t218;
    unsigned int t219;
    char *t220;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    char *t225;
    char *t226;
    char *t227;
    unsigned int t228;
    unsigned int t229;
    unsigned int t230;
    unsigned int t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    char *t235;
    char *t236;
    unsigned int t237;
    unsigned int t238;
    unsigned int t239;
    unsigned int t240;
    unsigned int t241;
    unsigned int t242;
    unsigned int t243;
    unsigned int t244;
    int t245;
    int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    unsigned int t252;
    char *t253;
    char *t254;
    char *t255;
    char *t257;
    unsigned int t258;
    unsigned int t259;
    unsigned int t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    unsigned int t265;
    unsigned int t266;
    unsigned int t267;
    unsigned int t268;
    unsigned int t269;
    char *t270;
    unsigned int t272;
    unsigned int t273;
    unsigned int t274;
    char *t275;
    char *t276;
    char *t277;
    unsigned int t278;
    unsigned int t279;
    unsigned int t280;
    unsigned int t281;
    unsigned int t282;
    unsigned int t283;
    unsigned int t284;
    char *t285;
    char *t286;
    unsigned int t287;
    unsigned int t288;
    unsigned int t289;
    unsigned int t290;
    unsigned int t291;
    unsigned int t292;
    unsigned int t293;
    unsigned int t294;
    int t295;
    int t296;
    unsigned int t297;
    unsigned int t298;
    unsigned int t299;
    unsigned int t300;
    unsigned int t301;
    unsigned int t302;
    char *t303;
    char *t304;
    char *t305;
    char *t307;
    unsigned int t308;
    unsigned int t309;
    unsigned int t310;
    unsigned int t311;
    unsigned int t312;
    unsigned int t313;
    unsigned int t314;
    unsigned int t315;
    unsigned int t316;
    unsigned int t317;
    unsigned int t318;
    unsigned int t319;
    char *t320;
    unsigned int t322;
    unsigned int t323;
    unsigned int t324;
    char *t325;
    char *t326;
    char *t327;
    unsigned int t328;
    unsigned int t329;
    unsigned int t330;
    unsigned int t331;
    unsigned int t332;
    unsigned int t333;
    unsigned int t334;
    char *t335;
    char *t336;
    unsigned int t337;
    unsigned int t338;
    unsigned int t339;
    unsigned int t340;
    unsigned int t341;
    unsigned int t342;
    unsigned int t343;
    unsigned int t344;
    int t345;
    int t346;
    unsigned int t347;
    unsigned int t348;
    unsigned int t349;
    unsigned int t350;
    unsigned int t351;
    unsigned int t352;
    char *t353;
    unsigned int t354;
    unsigned int t355;
    unsigned int t356;
    unsigned int t357;
    unsigned int t358;
    char *t359;
    char *t360;

LAB0:    t1 = (t0 + 3808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(10, ng0);
    t2 = (t0 + 4128);
    *((int *)t2) = 1;
    t3 = (t0 + 3840);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(11, ng0);

LAB5:    xsi_set_current_line(12, ng0);
    t5 = (t0 + 1048U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t0 + 1208U);
    t14 = *((char **)t13);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t14);
    t18 = (t16 | t17);
    *((unsigned int *)t15) = t18;
    t13 = (t4 + 4);
    t19 = (t14 + 4);
    t20 = (t15 + 4);
    t21 = *((unsigned int *)t13);
    t22 = *((unsigned int *)t19);
    t23 = (t21 | t22);
    *((unsigned int *)t20) = t23;
    t24 = *((unsigned int *)t20);
    t25 = (t24 != 0);
    if (t25 == 1)
        goto LAB10;

LAB11:
LAB12:    t42 = (t0 + 1368U);
    t43 = *((char **)t42);
    t45 = *((unsigned int *)t15);
    t46 = *((unsigned int *)t43);
    t47 = (t45 | t46);
    *((unsigned int *)t44) = t47;
    t42 = (t15 + 4);
    t48 = (t43 + 4);
    t49 = (t44 + 4);
    t50 = *((unsigned int *)t42);
    t51 = *((unsigned int *)t48);
    t52 = (t50 | t51);
    *((unsigned int *)t49) = t52;
    t53 = *((unsigned int *)t49);
    t54 = (t53 != 0);
    if (t54 == 1)
        goto LAB13;

LAB14:
LAB15:    t71 = (t0 + 1528U);
    t72 = *((char **)t71);
    t74 = *((unsigned int *)t44);
    t75 = *((unsigned int *)t72);
    t76 = (t74 | t75);
    *((unsigned int *)t73) = t76;
    t71 = (t44 + 4);
    t77 = (t72 + 4);
    t78 = (t73 + 4);
    t79 = *((unsigned int *)t71);
    t80 = *((unsigned int *)t77);
    t81 = (t79 | t80);
    *((unsigned int *)t78) = t81;
    t82 = *((unsigned int *)t78);
    t83 = (t82 != 0);
    if (t83 == 1)
        goto LAB16;

LAB17:
LAB18:    t100 = (t0 + 1688U);
    t101 = *((char **)t100);
    t103 = *((unsigned int *)t73);
    t104 = *((unsigned int *)t101);
    t105 = (t103 | t104);
    *((unsigned int *)t102) = t105;
    t100 = (t73 + 4);
    t106 = (t101 + 4);
    t107 = (t102 + 4);
    t108 = *((unsigned int *)t100);
    t109 = *((unsigned int *)t106);
    t110 = (t108 | t109);
    *((unsigned int *)t107) = t110;
    t111 = *((unsigned int *)t107);
    t112 = (t111 != 0);
    if (t112 == 1)
        goto LAB19;

LAB20:
LAB21:    t129 = (t102 + 4);
    t130 = *((unsigned int *)t129);
    t131 = (~(t130));
    t132 = *((unsigned int *)t102);
    t133 = (t132 & t131);
    t134 = (t133 != 0);
    if (t134 > 0)
        goto LAB22;

LAB23:
LAB24:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB10:    t26 = *((unsigned int *)t15);
    t27 = *((unsigned int *)t20);
    *((unsigned int *)t15) = (t26 | t27);
    t28 = (t4 + 4);
    t29 = (t14 + 4);
    t30 = *((unsigned int *)t28);
    t31 = (~(t30));
    t32 = *((unsigned int *)t4);
    t33 = (t32 & t31);
    t34 = *((unsigned int *)t29);
    t35 = (~(t34));
    t36 = *((unsigned int *)t14);
    t37 = (t36 & t35);
    t38 = (~(t33));
    t39 = (~(t37));
    t40 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t40 & t38);
    t41 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t41 & t39);
    goto LAB12;

LAB13:    t55 = *((unsigned int *)t44);
    t56 = *((unsigned int *)t49);
    *((unsigned int *)t44) = (t55 | t56);
    t57 = (t15 + 4);
    t58 = (t43 + 4);
    t59 = *((unsigned int *)t57);
    t60 = (~(t59));
    t61 = *((unsigned int *)t15);
    t62 = (t61 & t60);
    t63 = *((unsigned int *)t58);
    t64 = (~(t63));
    t65 = *((unsigned int *)t43);
    t66 = (t65 & t64);
    t67 = (~(t62));
    t68 = (~(t66));
    t69 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t69 & t67);
    t70 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t70 & t68);
    goto LAB15;

LAB16:    t84 = *((unsigned int *)t73);
    t85 = *((unsigned int *)t78);
    *((unsigned int *)t73) = (t84 | t85);
    t86 = (t44 + 4);
    t87 = (t72 + 4);
    t88 = *((unsigned int *)t86);
    t89 = (~(t88));
    t90 = *((unsigned int *)t44);
    t91 = (t90 & t89);
    t92 = *((unsigned int *)t87);
    t93 = (~(t92));
    t94 = *((unsigned int *)t72);
    t95 = (t94 & t93);
    t96 = (~(t91));
    t97 = (~(t95));
    t98 = *((unsigned int *)t78);
    *((unsigned int *)t78) = (t98 & t96);
    t99 = *((unsigned int *)t78);
    *((unsigned int *)t78) = (t99 & t97);
    goto LAB18;

LAB19:    t113 = *((unsigned int *)t102);
    t114 = *((unsigned int *)t107);
    *((unsigned int *)t102) = (t113 | t114);
    t115 = (t73 + 4);
    t116 = (t101 + 4);
    t117 = *((unsigned int *)t115);
    t118 = (~(t117));
    t119 = *((unsigned int *)t73);
    t120 = (t119 & t118);
    t121 = *((unsigned int *)t116);
    t122 = (~(t121));
    t123 = *((unsigned int *)t101);
    t124 = (t123 & t122);
    t125 = (~(t120));
    t126 = (~(t124));
    t127 = *((unsigned int *)t107);
    *((unsigned int *)t107) = (t127 & t125);
    t128 = *((unsigned int *)t107);
    *((unsigned int *)t107) = (t128 & t126);
    goto LAB21;

LAB22:    xsi_set_current_line(13, ng0);

LAB25:    xsi_set_current_line(14, ng0);
    t135 = (t0 + 1048U);
    t136 = *((char **)t135);
    t135 = (t0 + 1848U);
    t137 = *((char **)t135);
    memset(t138, 0, 8);
    t135 = (t136 + 4);
    t139 = (t137 + 4);
    t140 = *((unsigned int *)t136);
    t141 = *((unsigned int *)t137);
    t142 = (t140 ^ t141);
    t143 = *((unsigned int *)t135);
    t144 = *((unsigned int *)t139);
    t145 = (t143 ^ t144);
    t146 = (t142 | t145);
    t147 = *((unsigned int *)t135);
    t148 = *((unsigned int *)t139);
    t149 = (t147 | t148);
    t150 = (~(t149));
    t151 = (t146 & t150);
    if (t151 != 0)
        goto LAB29;

LAB26:    if (t149 != 0)
        goto LAB28;

LAB27:    *((unsigned int *)t138) = 1;

LAB29:    t153 = (t0 + 1208U);
    t154 = *((char **)t153);
    t153 = (t0 + 2008U);
    t155 = *((char **)t153);
    memset(t156, 0, 8);
    t153 = (t154 + 4);
    t157 = (t155 + 4);
    t158 = *((unsigned int *)t154);
    t159 = *((unsigned int *)t155);
    t160 = (t158 ^ t159);
    t161 = *((unsigned int *)t153);
    t162 = *((unsigned int *)t157);
    t163 = (t161 ^ t162);
    t164 = (t160 | t163);
    t165 = *((unsigned int *)t153);
    t166 = *((unsigned int *)t157);
    t167 = (t165 | t166);
    t168 = (~(t167));
    t169 = (t164 & t168);
    if (t169 != 0)
        goto LAB33;

LAB30:    if (t167 != 0)
        goto LAB32;

LAB31:    *((unsigned int *)t156) = 1;

LAB33:    t172 = *((unsigned int *)t138);
    t173 = *((unsigned int *)t156);
    t174 = (t172 & t173);
    *((unsigned int *)t171) = t174;
    t175 = (t138 + 4);
    t176 = (t156 + 4);
    t177 = (t171 + 4);
    t178 = *((unsigned int *)t175);
    t179 = *((unsigned int *)t176);
    t180 = (t178 | t179);
    *((unsigned int *)t177) = t180;
    t181 = *((unsigned int *)t177);
    t182 = (t181 != 0);
    if (t182 == 1)
        goto LAB34;

LAB35:
LAB36:    t203 = (t0 + 1368U);
    t204 = *((char **)t203);
    t203 = (t0 + 2168U);
    t205 = *((char **)t203);
    memset(t206, 0, 8);
    t203 = (t204 + 4);
    t207 = (t205 + 4);
    t208 = *((unsigned int *)t204);
    t209 = *((unsigned int *)t205);
    t210 = (t208 ^ t209);
    t211 = *((unsigned int *)t203);
    t212 = *((unsigned int *)t207);
    t213 = (t211 ^ t212);
    t214 = (t210 | t213);
    t215 = *((unsigned int *)t203);
    t216 = *((unsigned int *)t207);
    t217 = (t215 | t216);
    t218 = (~(t217));
    t219 = (t214 & t218);
    if (t219 != 0)
        goto LAB40;

LAB37:    if (t217 != 0)
        goto LAB39;

LAB38:    *((unsigned int *)t206) = 1;

LAB40:    t222 = *((unsigned int *)t171);
    t223 = *((unsigned int *)t206);
    t224 = (t222 & t223);
    *((unsigned int *)t221) = t224;
    t225 = (t171 + 4);
    t226 = (t206 + 4);
    t227 = (t221 + 4);
    t228 = *((unsigned int *)t225);
    t229 = *((unsigned int *)t226);
    t230 = (t228 | t229);
    *((unsigned int *)t227) = t230;
    t231 = *((unsigned int *)t227);
    t232 = (t231 != 0);
    if (t232 == 1)
        goto LAB41;

LAB42:
LAB43:    t253 = (t0 + 1528U);
    t254 = *((char **)t253);
    t253 = (t0 + 2328U);
    t255 = *((char **)t253);
    memset(t256, 0, 8);
    t253 = (t254 + 4);
    t257 = (t255 + 4);
    t258 = *((unsigned int *)t254);
    t259 = *((unsigned int *)t255);
    t260 = (t258 ^ t259);
    t261 = *((unsigned int *)t253);
    t262 = *((unsigned int *)t257);
    t263 = (t261 ^ t262);
    t264 = (t260 | t263);
    t265 = *((unsigned int *)t253);
    t266 = *((unsigned int *)t257);
    t267 = (t265 | t266);
    t268 = (~(t267));
    t269 = (t264 & t268);
    if (t269 != 0)
        goto LAB47;

LAB44:    if (t267 != 0)
        goto LAB46;

LAB45:    *((unsigned int *)t256) = 1;

LAB47:    t272 = *((unsigned int *)t221);
    t273 = *((unsigned int *)t256);
    t274 = (t272 & t273);
    *((unsigned int *)t271) = t274;
    t275 = (t221 + 4);
    t276 = (t256 + 4);
    t277 = (t271 + 4);
    t278 = *((unsigned int *)t275);
    t279 = *((unsigned int *)t276);
    t280 = (t278 | t279);
    *((unsigned int *)t277) = t280;
    t281 = *((unsigned int *)t277);
    t282 = (t281 != 0);
    if (t282 == 1)
        goto LAB48;

LAB49:
LAB50:    t303 = (t0 + 1688U);
    t304 = *((char **)t303);
    t303 = (t0 + 2488U);
    t305 = *((char **)t303);
    memset(t306, 0, 8);
    t303 = (t304 + 4);
    t307 = (t305 + 4);
    t308 = *((unsigned int *)t304);
    t309 = *((unsigned int *)t305);
    t310 = (t308 ^ t309);
    t311 = *((unsigned int *)t303);
    t312 = *((unsigned int *)t307);
    t313 = (t311 ^ t312);
    t314 = (t310 | t313);
    t315 = *((unsigned int *)t303);
    t316 = *((unsigned int *)t307);
    t317 = (t315 | t316);
    t318 = (~(t317));
    t319 = (t314 & t318);
    if (t319 != 0)
        goto LAB54;

LAB51:    if (t317 != 0)
        goto LAB53;

LAB52:    *((unsigned int *)t306) = 1;

LAB54:    t322 = *((unsigned int *)t271);
    t323 = *((unsigned int *)t306);
    t324 = (t322 & t323);
    *((unsigned int *)t321) = t324;
    t325 = (t271 + 4);
    t326 = (t306 + 4);
    t327 = (t321 + 4);
    t328 = *((unsigned int *)t325);
    t329 = *((unsigned int *)t326);
    t330 = (t328 | t329);
    *((unsigned int *)t327) = t330;
    t331 = *((unsigned int *)t327);
    t332 = (t331 != 0);
    if (t332 == 1)
        goto LAB55;

LAB56:
LAB57:    t353 = (t321 + 4);
    t354 = *((unsigned int *)t353);
    t355 = (~(t354));
    t356 = *((unsigned int *)t321);
    t357 = (t356 & t355);
    t358 = (t357 != 0);
    if (t358 > 0)
        goto LAB58;

LAB59:    xsi_set_current_line(17, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB60:    goto LAB24;

LAB28:    t152 = (t138 + 4);
    *((unsigned int *)t138) = 1;
    *((unsigned int *)t152) = 1;
    goto LAB29;

LAB32:    t170 = (t156 + 4);
    *((unsigned int *)t156) = 1;
    *((unsigned int *)t170) = 1;
    goto LAB33;

LAB34:    t183 = *((unsigned int *)t171);
    t184 = *((unsigned int *)t177);
    *((unsigned int *)t171) = (t183 | t184);
    t185 = (t138 + 4);
    t186 = (t156 + 4);
    t187 = *((unsigned int *)t138);
    t188 = (~(t187));
    t189 = *((unsigned int *)t185);
    t190 = (~(t189));
    t191 = *((unsigned int *)t156);
    t192 = (~(t191));
    t193 = *((unsigned int *)t186);
    t194 = (~(t193));
    t195 = (t188 & t190);
    t196 = (t192 & t194);
    t197 = (~(t195));
    t198 = (~(t196));
    t199 = *((unsigned int *)t177);
    *((unsigned int *)t177) = (t199 & t197);
    t200 = *((unsigned int *)t177);
    *((unsigned int *)t177) = (t200 & t198);
    t201 = *((unsigned int *)t171);
    *((unsigned int *)t171) = (t201 & t197);
    t202 = *((unsigned int *)t171);
    *((unsigned int *)t171) = (t202 & t198);
    goto LAB36;

LAB39:    t220 = (t206 + 4);
    *((unsigned int *)t206) = 1;
    *((unsigned int *)t220) = 1;
    goto LAB40;

LAB41:    t233 = *((unsigned int *)t221);
    t234 = *((unsigned int *)t227);
    *((unsigned int *)t221) = (t233 | t234);
    t235 = (t171 + 4);
    t236 = (t206 + 4);
    t237 = *((unsigned int *)t171);
    t238 = (~(t237));
    t239 = *((unsigned int *)t235);
    t240 = (~(t239));
    t241 = *((unsigned int *)t206);
    t242 = (~(t241));
    t243 = *((unsigned int *)t236);
    t244 = (~(t243));
    t245 = (t238 & t240);
    t246 = (t242 & t244);
    t247 = (~(t245));
    t248 = (~(t246));
    t249 = *((unsigned int *)t227);
    *((unsigned int *)t227) = (t249 & t247);
    t250 = *((unsigned int *)t227);
    *((unsigned int *)t227) = (t250 & t248);
    t251 = *((unsigned int *)t221);
    *((unsigned int *)t221) = (t251 & t247);
    t252 = *((unsigned int *)t221);
    *((unsigned int *)t221) = (t252 & t248);
    goto LAB43;

LAB46:    t270 = (t256 + 4);
    *((unsigned int *)t256) = 1;
    *((unsigned int *)t270) = 1;
    goto LAB47;

LAB48:    t283 = *((unsigned int *)t271);
    t284 = *((unsigned int *)t277);
    *((unsigned int *)t271) = (t283 | t284);
    t285 = (t221 + 4);
    t286 = (t256 + 4);
    t287 = *((unsigned int *)t221);
    t288 = (~(t287));
    t289 = *((unsigned int *)t285);
    t290 = (~(t289));
    t291 = *((unsigned int *)t256);
    t292 = (~(t291));
    t293 = *((unsigned int *)t286);
    t294 = (~(t293));
    t295 = (t288 & t290);
    t296 = (t292 & t294);
    t297 = (~(t295));
    t298 = (~(t296));
    t299 = *((unsigned int *)t277);
    *((unsigned int *)t277) = (t299 & t297);
    t300 = *((unsigned int *)t277);
    *((unsigned int *)t277) = (t300 & t298);
    t301 = *((unsigned int *)t271);
    *((unsigned int *)t271) = (t301 & t297);
    t302 = *((unsigned int *)t271);
    *((unsigned int *)t271) = (t302 & t298);
    goto LAB50;

LAB53:    t320 = (t306 + 4);
    *((unsigned int *)t306) = 1;
    *((unsigned int *)t320) = 1;
    goto LAB54;

LAB55:    t333 = *((unsigned int *)t321);
    t334 = *((unsigned int *)t327);
    *((unsigned int *)t321) = (t333 | t334);
    t335 = (t271 + 4);
    t336 = (t306 + 4);
    t337 = *((unsigned int *)t271);
    t338 = (~(t337));
    t339 = *((unsigned int *)t335);
    t340 = (~(t339));
    t341 = *((unsigned int *)t306);
    t342 = (~(t341));
    t343 = *((unsigned int *)t336);
    t344 = (~(t343));
    t345 = (t338 & t340);
    t346 = (t342 & t344);
    t347 = (~(t345));
    t348 = (~(t346));
    t349 = *((unsigned int *)t327);
    *((unsigned int *)t327) = (t349 & t347);
    t350 = *((unsigned int *)t327);
    *((unsigned int *)t327) = (t350 & t348);
    t351 = *((unsigned int *)t321);
    *((unsigned int *)t321) = (t351 & t347);
    t352 = *((unsigned int *)t321);
    *((unsigned int *)t321) = (t352 & t348);
    goto LAB57;

LAB58:    xsi_set_current_line(15, ng0);
    t359 = ((char*)((ng1)));
    t360 = (t0 + 2888);
    xsi_vlogvar_assign_value(t360, t359, 0, 0, 1);
    goto LAB60;

}


extern void work_m_00000000002786881853_3644784444_init()
{
	static char *pe[] = {(void *)Always_10_0};
	xsi_register_didat("work_m_00000000002786881853_3644784444", "isim/multibanco_isim_beh.exe.sim/work/m_00000000002786881853_3644784444.didat");
	xsi_register_executes(pe);
}
